package classloader;

public interface Versioned {
	String getVersion();
}
