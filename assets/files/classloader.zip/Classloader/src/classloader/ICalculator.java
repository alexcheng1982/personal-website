package classloader;

public interface ICalculator extends Versioned {
	String calculate(String expression);
}
